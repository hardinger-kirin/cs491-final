defmodule Sms.HumanResources.Employee do
  defstruct id: nil, first_name: nil, last_name: nil, id_number: nil, department: nil, hire_date: nil
end
