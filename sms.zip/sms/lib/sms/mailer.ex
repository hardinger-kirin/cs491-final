defmodule Sms.Mailer do
  use Swoosh.Mailer, otp_app: :sms
end
