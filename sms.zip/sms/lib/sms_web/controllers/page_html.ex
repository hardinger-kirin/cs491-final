defmodule SmsWeb.PageHTML do
  use SmsWeb, :html

  embed_templates "page_html/*"
end
