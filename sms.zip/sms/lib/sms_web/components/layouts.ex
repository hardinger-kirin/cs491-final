defmodule SmsWeb.Layouts do
  use SmsWeb, :html

  embed_templates "layouts/*"
end
