defmodule Final.Mailer do
  use Swoosh.Mailer, otp_app: :final
end
