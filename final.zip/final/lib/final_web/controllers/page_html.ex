defmodule FinalWeb.PageHTML do
  use FinalWeb, :html

  embed_templates "page_html/*"
end
