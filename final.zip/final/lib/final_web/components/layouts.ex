defmodule FinalWeb.Layouts do
  use FinalWeb, :html

  embed_templates "layouts/*"
end
